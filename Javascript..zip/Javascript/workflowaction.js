before_workflow_action: (frm) => {
    console.log(frm.selected_workflow_action);
    if (
        // draft workflow
        frm.doc.workflow_state === "Draft" &&
        frm.selected_workflow_action === "Submit"
    ) frappe.msgprint({
        title: "Submitted",
        message: "Task Sent to Responsible Person "+ frm.doc.responsible_person +" for futher action "+ frm.doc.name,
        indicator: 'Green',
        primary_action: {
            action: function(){
                frappe.hide_msgprint();
            },
            label: 'OK'
        }
        });
    if (
        // Assigned to the responsible person action
        frm.doc.workflow_state === "Assigned to the Responsible Person" &&
        frm.selected_workflow_action === "Submit"
    ) frappe.msgprint({
        title: "Submitted",
        message: "Premise Identification Complete and Sent to the Region Head for the Confirmation",
        indicator: 'Green',
        primary_action: {
            action: function(){
                frappe.hide_msgprint();
            },
            label: 'OK'
        }
        });
    if (
        // Assigned to the Approval pending with the RB Manager action Approve
        frm.doc.workflow_state === "Approval pending with RB Manager" &&
        frm.selected_workflow_action === "Approve"
    ) frappe.msgprint({
        title: "Approved",
        message: "Premise Identification Complete and Send to Management Approval",
        indicator: 'Green',
        primary_action: {
            action: function(){
                frappe.hide_msgprint();
            },
            label: 'OK'
        }
        });
    if (
        // Assigned to the Approval pending with the RB Manager action Reject
        frm.doc.workflow_state === "Approval pending with RB Manager" &&
        frm.selected_workflow_action === "Reject"
    ) frappe.msgprint({
        title: "Rejected",
        message: "Rejected assigned to the Branch Responsible person "+ frm.doc.responsible_person,
        indicator: 'Red',
        primary_action: {
            action: function(){
                frappe.hide_msgprint();
            },
            label: 'OK'
        }
        });
    if (
        // Assigned to the Approval pending with Approval Manager action Approve
        frm.doc.workflow_state === "Approval pending with Approval Manager" &&
        frm.selected_workflow_action === "Approve"
    ) frappe.msgprint({
        title: "Approved",
        message: "Approved assigned to the Branch Initiator Group",
        indicator: 'Green',
        primary_action: {
            action: function(){
                frappe.hide_msgprint();
            },
            label: 'OK'
        }
        });
    if (
        // Assigned to the Approval pending with Approval Manager action Reject
        frm.doc.workflow_state === "Approval pending with Approval Manager" &&
        frm.selected_workflow_action === "Reject"
    ) frappe.msgprint({
        title: "Rejected",
        message: "Rejected assigned to the Branch Responsible person "+ frm.doc.responsible_person,
        indicator: 'Red',
        primary_action: {
            action: function(){
                frappe.hide_msgprint();
            },
            label: 'OK'
        }
        });
    if (
        // Assigned to the Approval pending with Branch Initiator Group
        frm.doc.workflow_state === "Complete" &&
        frm.selected_workflow_action === "Complete"
    ) frappe.msgprint({
        title: "Completed",
        message: "Data updated successfully. Branch request successfully completed",
        indicator: 'Red',
        primary_action: {
            action: function(){
                frappe.hide_msgprint();
            },
            label: 'OK'
        }
        });
    if (
        // Assigned to the Approval pending with Branch Initiator Group
        frm.doc.workflow_state === "Complete" &&
        frm.selected_workflow_action === "Cancel"
    ) frappe.msgprint({
        title: "Rejected",
        message: "Rejected assigned to the Branch Responsible person "+ frm.doc.responsible_person,
        indicator: 'Red',
        primary_action: {
            action: function(){
                frappe.hide_msgprint();
            },
            label: 'OK'
        }
    });
}