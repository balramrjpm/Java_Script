// Check if Frappe library is available (optional but recommended)
//}

frappe.ui.form.on('Sample_doc', {
    refresh: function(frm) {
      frm.trigger('update_audit_trail');
    },
    after_save: function(frm) {
      frm.trigger('update_audit_trail');
    },
    update_audit_trail: function(frm) {
      if (!frm.doc.audit_details) {
        frm.doc.audit_details = [];
      }
  
      let audit_entry = {
        no: frm.doc.audit_details.length + 1,
        step_name: 'Step Name', // Customize as needed
        performer_role: frappe.user_roles.join(', '),
        performer: frappe.session.user,
        datetime: frappe.datetime.now_datetime(), // Assuming frappe is available
        action_name: 'Action Name', // Customize as needed
        remark: 'Remark', // Customize as needed
        // Update date_and_time here to reflect user action time
        
      };
  
      frm.add_child('audit_details', audit_entry);
      frm.refresh_field('audit_details');
    }
  });
  