frappe.ui.form.on('Proposed Branch Details', {
	setup(frm) {
        // script for the producing the list of the past ten year
        let currentDate = new Date();
        // let formattedDate = frappe.datetime.str_to_user(currentDate, 'dd-mm-yyyy');
		let formattedDate = frappe.datetime.nowdate();
		let currentYear = new Date().getFullYear();
        let yearList = [];
        for(let i = 0; i < 10; i++) {
            yearList.push((currentYear - i) + "-" + (currentYear - i + 1));
        
	   }
	    frm.set_df_property('year', 'options', yearList);
	    frm.set_value('initiated_by', cur_frm.doc.owner);
	    frm.set_value('intiated_date', formattedDate);
	    frm.save();
	},
    refresh(frm) {
        let currentDate = new Date();
        // let formattedDate = frappe.datetime.str_to_user(currentDate, 'dd-mm-yyyy');
		let formattedDate = frappe.datetime.nowdate();
		let currentYear = new Date().getFullYear();
        let yearList = [];
        for(let i = 0; i < 10; i++) {
            yearList.push((currentYear - i) + "-" + (currentYear - i + 1));
        	}
	    frm.set_df_property('year', 'options', yearList);
	   // frm.set_value('initiated_by', frappe.session.user);
	   frm.set_value('initiated_by', cur_frm.doc.owner);
	   frm.set_value('intiated_date', formattedDate);
	   
        frappe.call({
            method: "frappe.client.get_list",
            args: {
                doctype: "New Branch Details",
                filters: {
                    year: frm.doc.year,
                    initiate: 1
                },
                fields: ["product_line","branch_category","zone","region","area","location_details"]
            },
            callback: function(r) {
                
                var product_line_options = r.message.map(function(d) { return d.product_line; });
                var branch_category_options = r.message.map(function(d) { return d.branch_category; });
                var zone_options = r.message.map(function(d) { return d.zone; });
                var region_options = r.message.map(function(d) { return d.region; });
                var area_options = r.message.map(function(d) { return d.area; });
                var location_details_options = r.message.map(function(d) { return d.location_details; });
                

                frm.set_df_property('product_line', 'options', product_line_options.join('\n'));
                frm.set_df_property('branch_category', 'options', branch_category_options.join('\n'));
                frm.set_df_property('zone', 'options', zone_options.join('\n'));                    
                frm.set_df_property('region', 'options', region_options.join('\n'));
                frm.set_df_property('area', 'options', area_options.join('\n'));
                frm.set_df_property('location_details', 'options', location_details_options.join('\n'));
            }
        });
    },
	// updating the regional list based on the zone selection
    year: function(frm) {
        var batch_size = 50;  // Number of records to fetch per batch
        var offset = 0;       // Starting offset    
        function fetchRecords() {
            frappe.call({
                method: "frappe.client.get_list",
                args: {
                    doctype: "New Branch Details",
                    filters: {
                        year: frm.doc.year,
                        initiate: 1
                    },
                    fields: ["product_line","branch_category","zone","region","area","location_details"],
                    limit_start: offset,
                    limit_page_length: batch_size
                },
                callback: function(r) {
                    
                    var product_line_options = r.message.map(function(d) { return d.product_line; });
                    var branch_category_options = r.message.map(function(d) { return d.branch_category; });
                    var zone_options = r.message.map(function(d) { return d.zone; });
                    var region_options = r.message.map(function(d) { return d.region; });
                    var area_options = r.message.map(function(d) { return d.area; });
                    var location_details_options = r.message.map(function(d) { return d.location_details; });
                    

                    frm.set_df_property('product_line', 'options', product_line_options.join('\n'));
                    frm.set_df_property('branch_category', 'options', branch_category_options.join('\n'));
                    frm.set_df_property('zone', 'options', zone_options.join('\n'));                    
                    frm.set_df_property('region', 'options', region_options.join('\n'));
                    frm.set_df_property('area', 'options', area_options.join('\n'));
                    frm.set_df_property('location_details', 'options', location_details_options.join('\n'));
    
                    // If there are more records, fetch the next batch
                    if (r.message && r.message.length === batch_size) {
                        offset += batch_size;
                        fetchRecords();
                    }
                }
            });
        }
            fetchRecords();  // Start fetching records
    },
    // map choose location
    map:function(frm){
        // console.log(JSON.parse(frm.doc.map));
        let mapdata = JSON.parse(cur_frm.doc.map).features[0];
        if(mapdata && mapdata.geometry.type =='Point'){
            let lat = mapdata.geometry.coordinates[1];
        	let lon = mapdata.geometry.coordinates[0];
        // 	console.log(lon,lat);
        	
        	frappe.call({
        		type: "GET",
        		url: `https://nominatim.openstreetmap.org/reverse?format=json&lat=${lat}&lon=${lon}`,
        		callback: function(r) {
        		  //  console.log(r.display_name);
        		    frm.set_value('geo_location', r.display_name);
        		}
        	});
        }
    },
//     after_save(frm) {
// 	// your code here
//         console.log("Submit");
//             frappe.msgprint({
//                 title: "Submitted",
//                 message: "Data saved and sent to process,\n Request No: "+ frm.doc.name,
//                 indicator: 'Green',
//                 primary_action: {
//                     action: function(){
//                         frappe.hide_msgprint();
//                     },
//                     label: 'OK'
//                 }
//             });
//     },
    before_workflow_action: (frm) => {
        console.log(frm.selected_workflow_action);
        if (
            // draft workflow
            frm.doc.workflow_state === "Draft" &&
            frm.selected_workflow_action === "Submit"
        ) frappe.msgprint({
            title: "Submitted",
            message: "Data saved and sent to process,\n Request No: "+ frm.doc.name + "\n Task Sent to Responsible Person \n"+ frm.doc.responsible_person +" for futher action",
            indicator: 'Green',
            primary_action: {
                action: function(){
                    frappe.hide_msgprint();
                },
                label: 'OK'
            }
            });
        if (
            // Assigned to the responsible person action
            frm.doc.workflow_state === "Assigned to the Responsible Person" &&
            frm.selected_workflow_action === "Submit"
        ) frappe.msgprint({
            title: "Submitted",
            message: "Premise Identification Complete and Sent to the Region Head for the Confirmation",
            indicator: 'Green',
            primary_action: {
                action: function(){
                    frappe.hide_msgprint();
                },
                label: 'OK'
            }
            });
        if (
            // Assigned to the Approval pending with the RB Manager action Approve
            frm.doc.workflow_state === "Approval pending with RB Manager" &&
            frm.selected_workflow_action === "Approve"
        ) frappe.msgprint({
            title: "Approved",
            message: "Premise Identification Complete and Send to Management Approval",
            indicator: 'Green',
            primary_action: {
                action: function(){
                    frappe.hide_msgprint();
                },
                label: 'OK'
            }
            });
        if (
            // Assigned to the Approval pending with the RB Manager action Reject
            frm.doc.workflow_state === "Approval pending with RB Manager" &&
            frm.selected_workflow_action === "Reject"
        ) frappe.msgprint({
            title: "Rejected",
            message: "Rejected assigned to the Branch Responsible person "+ frm.doc.responsible_person,
            indicator: 'Red',
            primary_action: {
                action: function(){
                    frappe.hide_msgprint();
                },
                label: 'OK'
            }
            });
        if (
            // Assigned to the Approval pending with Approval Manager action Approve
            frm.doc.workflow_state === "Approval pending with Approval Manager" &&
            frm.selected_workflow_action === "Approve"
        ) frappe.msgprint({
            title: "Approved",
            message: "Approved assigned to the Branch Initiator Group",
            indicator: 'Green',
            primary_action: {
                action: function(){
                    frappe.hide_msgprint();
                },
                label: 'OK'
            }
            });
        if (
            // Assigned to the Approval pending with Approval Manager action Reject
            frm.doc.workflow_state === "Approval pending with Approval Manager" &&
            frm.selected_workflow_action === "Reject"
        ) frappe.msgprint({
            title: "Rejected",
            message: "Rejected assigned to the Branch Responsible person "+ frm.doc.responsible_person,
            indicator: 'Red',
            primary_action: {
                action: function(){
                    frappe.hide_msgprint();
                },
                label: 'OK'
            }
            });
        if (
            // Assigned to the Approval pending with Branch Initiator Group
            frm.doc.workflow_state === "Assigned to the Group Queue" &&
            frm.selected_workflow_action === "Complete"
        ) frappe.msgprint({
            title: "Completed",
            message: "Data updated successfully. Branch request successfully completed",
            indicator: 'Red',
            primary_action: {
                action: function(){
                    frappe.hide_msgprint();
                },
                label: 'OK'
            }
            });
        if (
            // Assigned to the Approval pending with Branch Initiator Group
            frm.doc.workflow_state === "Complete" &&
            frm.selected_workflow_action === "Cancel"
        ) frappe.msgprint({
            title: "Rejected",
            message: "Rejected assigned to the Branch Responsible person "+ frm.doc.responsible_person,
            indicator: 'Red',
            primary_action: {
                action: function(){
                    frappe.hide_msgprint();
                },
                label: 'OK'
            }
        });
    }
});