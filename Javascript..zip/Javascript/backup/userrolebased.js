frappe.ui.form.on('Proposed Branch Details', {
	setup(frm) {
        let hasRole = frappe.user_roles.includes('Branch Initiator');

        // Hide or show sections based on the user's role
        frm.toggle_display('premise_information_section', !hasRole);
        frm.toggle_display('premise_related_information_section', !hasRole);
        frm.toggle_display('approvers_remark', !hasRole);
        frm.toggle_display('audit_trail_details_section', !hasRole);
        frm.toggle_display('commercial_details_section', !hasRole);
        frm.toggle_display('facilities_provided_section', !hasRole);
        frm.toggle_display('property_details_section', !hasRole);
        frm.toggle_display('owner_details_section', !hasRole);
        frm.toggle_display('owner_2_details_section', false); // Assuming this should be hidden by default
        frm.toggle_display('owner_3_details_section', false); // Assuming this should be hidden by default
        frm.toggle_display('deviation_and_other_details_section', !hasRole);

        // Make fields required based on the user's role or other conditions
        if (!hasRole && (frm.doc.responsible_person == frappe.session.user_email || frappe.user_roles.includes('Branch Responsible Person'))) {
            const requiredFields = [
                'rent_per_sq_feet', 'monthly_rent', 'security_deposit', 'maintenance',
                'lock_in_period', 'rent_free_period', 'stamp_duty_and_legal_expense_sharing_ratio_for_registration',
                'rent_escalation', 'lease_period', 'lease_exit_notice_period_from_lessee',
                'property_tax_liability', 'brokerage', 'reimbursement_by_landlord',
                'furnished_or_unfurnished_office', 'signage_space_and_location_details',
                'electricity_load_in_kva', 'wiring_to_be_provided_till_db_box_in_our_premises',
                'water_line_specify_source', 'sewer_line_specify_source', 'parking_space_or_area',
                'parking_number_of_two_wheeler', 'parking_number_of_four_wheeler',
                'number_of_exclusive_toilets_available', 'flooring_available_vitrifies_tile_or_ceramic_tile_or_carpet',
                'availability_of_fire_exit', 'lift_availability', 'rolling_shutter_in_the_front',
                'space_for_generator_set', 'is_space_for_generator_rent_free', 'earth_points',
                'specify_space_for_ac_outdoor_unit', 'availability_of_space_for_rf_pole',
                'is_space_for_rf_pole_rent_free', 'availability_of_electrical_or_data_or_voice_cabling',
                'windows_with_safety_grills', 'availability_of_pantry', 'total_no_of_floors_in_the_building',
                'complete_address_of_the_property', 'proposed_floor_level', 'pin_code',
                'geo_latitude', 'geo_longitude', 'basis_of_rent_calculation', 'bound_by_north',
                'bound_by_east', 'bound_by_south', 'bound_by_west', 'built_up_area_sqft',
                'carpet_area_sqft', 'ownerlandlord_name', 'owner_age', 'owners_father_or_spouse_name',
                'complete_address_of_the_owner', 'phone_number', 'email_address', 'pan_number',
                'gst_number', 'agreement_signed_by', 'poasauthorised_signatorys_name',
                'poas_authorised_signatorys_age', 'poasauthorised_signatorys_fathers_or_spouse_name',
                'poasauthorised_signatorys_complete_address', 'deviation_details_if_any', 'remark'
            ];
            requiredFields.forEach(field => frm.set_df_property(field, 'reqd', 1));
        }
	},
    add_owner: function(frm) {
        frm.toggle_display('owner_2_details_section', true); // Assuming you want to show the section
    
        const owner2Fields = [
            'owner2landlord_name', 'owner2_age', 'owners2_father_or_spouse_name',
            'complete_address_of_the_owner2', 'phone_number2', 'email2_address',
            'pan_number2', 'gst_number2', 'agreement2_signed_by', 'poasauthorised2_signatorys_name',
            'poas_authorised2_signatorys_age', 'poasauthorised2_signatorys_fathers_or_spouse_name',
            'poasauthorised2_signatorys_complete_address'
        ];
    
        owner2Fields.forEach(field => frm.set_df_property(field, 'reqd', 1));
    },
    add_owner2: function(frm) {
        frm.toggle_display('owner_3_details_section', true); // Assuming you want to show the section
    
        const owner3Fields = [
            'owner3landlord_name', 'owner3_age', 'owners3_father_or_spouse_name',
            'complete_address_of_the_owner3', 'phone_number3', 'email3_address',
            'pan_number3', 'gst_number3', 'agreement3_signed_by', 'poasauthorised3_signatorys_name',
            'poas_authorised3_signatorys_age', 'poasauthorised3_signatorys_fathers_or_spouse_name',
            'poasauthorised3_signatorys_complete_address'
        ];
    
        owner3Fields.forEach(field => frm.set_df_property(field, 'reqd', 1));
    },
    premise_information: function(frm){
        premise_value = frm.doc.premise_information;
        if (premise_value === "Deviation and Other Details")
        frm.toggle_display('owner_2_details_section', false);
        frm.toggle_display('owner_3_details_section', false);
    }
});