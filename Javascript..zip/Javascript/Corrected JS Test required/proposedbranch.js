frappe.ui.form.on('Proposed Branch Details', {
	setup(frm) {
        // script for producing the list of the past ten years
        let currentDate = new Date();
        let currentYear = currentDate.getFullYear();
        let yearList = [];
    
        for (let i = 0; i < 10; i++) {
            yearList.push(`${currentYear - i} - ${currentYear - i + 1}`);
        }
    
        frm.set_df_property('year', 'options', yearList);
        frm.set_value('initiated_by', frm.doc.owner); // Assuming frm.doc.owner is the correct way to get the current user
        frm.set_value('initiated_date', frappe.datetime.nowdate()); // Assuming frappe.datetime.nowdate() returns the date in the correct format
    },    
    refresh(frm) {
        let currentDate = new Date();
        let formattedDate = frappe.datetime.nowdate();
        let currentYear = currentDate.getFullYear();
        let yearList = [];
    
        for (let i = 0; i < 10; i++) {
            yearList.push(`${currentYear - i} - ${currentYear - i + 1}`);
        }
    
        frm.set_df_property('year', 'options', yearList.join('\n'));
        frm.set_value('initiated_by', frm.doc.owner);
        frm.set_value('initiated_date', formattedDate);
    
        frappe.call({
            method: "frappe.client.get_list",
            args: {
                doctype: "New Branch Details",
                filters: {
                    year: frm.doc.year,
                    initiate: 1
                },
                fields: ["product_line", "branch_category", "zone", "region", "area", "location_details"]
            },
            callback: function(r) {
                if (r.message) {
                    const uniqueOptions = (field) => [...new Set(r.message.map(d => d[field]))].join('\n');
    
                    frm.set_df_property('product_line', 'options', uniqueOptions('product_line'));
                    frm.set_df_property('branch_category', 'options', uniqueOptions('branch_category'));
                    frm.set_df_property('zone', 'options', uniqueOptions('zone'));
                    frm.set_df_property('region', 'options', uniqueOptions('region'));
                    frm.set_df_property('area', 'options', uniqueOptions('area'));
                    frm.set_df_property('location_details', 'options', uniqueOptions('location_details'));
                }
            }
        });
    },
	// updating the regional list based on the zone selection
    year: function(frm) {
        const batchSize = 50; // Number of records to fetch per batch
        let offset = 0; // Starting offset

        const fetchRecords = () => {
            frappe.call({
                method: "frappe.client.get_list",
                args: {
                    doctype: "New Branch Details",
                    filters: {
                        year: frm.doc.year,
                        initiate: 1
                    },
                    fields: ["product_line", "branch_category", "zone", "region", "area", "location_details"],
                    limit_start: offset,
                    limit_page_length: batchSize
                },
                callback: (r) => {
                    if (r.message) {
                        const uniqueOptions = (field) => [...new Set(r.message.map(d => d[field]))].join('\n');

                        frm.set_df_property('product_line', 'options', uniqueOptions('product_line'));
                        frm.set_df_property('branch_category', 'options', uniqueOptions('branch_category'));
                        frm.set_df_property('zone', 'options', uniqueOptions('zone'));
                        frm.set_df_property('region', 'options', uniqueOptions('region'));
                        frm.set_df_property('area', 'options', uniqueOptions('area'));
                        frm.set_df_property('location_details', 'options', uniqueOptions('location_details'));
                    }

                    // If there are more records, fetch the next batch
                    if (r.message && r.message.length === batchSize) {
                        offset += batchSize;
                        fetchRecords();
                    }
                }
            });
        };

        fetchRecords(); // Start fetching records
    },
    // map choose location
    map: function(frm) {
        // Parse the map data from the form's document
        let mapdata = JSON.parse(frm.doc.map).features[0];
        
        // Check if the map data exists and is of type 'Point'
        if (mapdata && mapdata.geometry.type === 'Point') {
            // Extract latitude and longitude from the coordinates
            let lat = mapdata.geometry.coordinates[1];
            let lon = mapdata.geometry.coordinates[0];
    
            // Make a GET request to the Nominatim API to reverse geocode the coordinates
            frappe.call({
                type: "GET",
                url: `https://nominatim.openstreetmap.org/reverse?format=jsonv2&lat=${lat}&lon=${lon}`,
                callback: function(response) {
                    // Set the 'geo_location' field in the form to the display name from the API response
                    frm.set_value('geo_location', response.message.display_name);
                }
            });
        }
    },
//     
    before_workflow_action: (frm) => {
        const showMessage = (title, message, indicator) => {
            frappe.msgprint({
                title: title,
                message: message,
                indicator: indicator,
                primary_action: {
                    action: function() {
                        frappe.hide_msgprint();
                    },
                    label: 'OK'
                }
            });
        };

        if (frm.doc.workflow_state === "Draft" && frm.selected_workflow_action === "Submit") {
            showMessage("Submitted", `Data saved and sent to process,\n Request No: ${frm.doc.name} \n Task Sent to Responsible Person \n${frm.doc.responsible_person} for further action`, 'Green');
        }

        if (frm.doc.workflow_state === "Assigned to the Responsible Person" && frm.selected_workflow_action === "Submit") {
            showMessage("Submitted", "Premise Identification Complete and Sent to the Region Head for Confirmation", 'Green');
        }

        if (frm.doc.workflow_state === "Approval pending with RB Manager" && frm.selected_workflow_action === "Approve") {
            showMessage("Approved", "Premise Identification Complete and Send to Management Approval", 'Green');
        }

        if (frm.doc.workflow_state === "Approval pending with RB Manager" && frm.selected_workflow_action === "Reject") {
            showMessage("Rejected", `Rejected assigned to the Branch Responsible person ${frm.doc.responsible_person}`, 'Red');
        }

        if (frm.doc.workflow_state === "Approval pending with Approval Manager" && frm.selected_workflow_action === "Approve") {
            showMessage("Approved", "Approved assigned to the Branch Initiator Group", 'Green');
        }

        if (frm.doc.workflow_state === "Approval pending with Approval Manager" && frm.selected_workflow_action === "Reject") {
            showMessage("Rejected", `Rejected assigned to the Branch Responsible person ${frm.doc.responsible_person}`, 'Red');
        }

        if (frm.doc.workflow_state === "Assigned to the Group Queue" && frm.selected_workflow_action === "Complete") {
            showMessage("Completed", "Data updated successfully. Branch request successfully completed", 'Green');
        }

        if (frm.doc.workflow_state === "Complete" && frm.selected_workflow_action === "Cancel") {
            showMessage("Cancelled", `Cancelled assigned to the Branch Responsible person ${frm.doc.responsible_person}`, 'Red');
        }
    },
});