frappe.ui.form.on('Proposed Branch Details', {
	setup(frm) {
        // script for the producing the list of the past ten year
        let currentDate = new Date();
        // let formattedDate = frappe.datetime.str_to_user(currentDate, 'dd-mm-yyyy');
		let formattedDate = frappe.datetime.nowdate();
		let currentYear = new Date().getFullYear();
        let yearList = [];
        for(let i = 0; i < 10; i++) {
            yearList.push((currentYear - i) + "-" + (currentYear - i + 1));
        
	   }
	    frm.set_df_property('year', 'options', yearList);
	    frm.set_value('initiated_by', cur_frm.doc.owner);
	    frm.set_value('intiated_date', formattedDate);
	},
    refresh(frm) {
        let currentDate = new Date();
        // let formattedDate = frappe.datetime.str_to_user(currentDate, 'dd-mm-yyyy');
		let formattedDate = frappe.datetime.nowdate();
		let currentYear = new Date().getFullYear();
        let yearList = [];
        for(let i = 0; i < 10; i++) {
            yearList.push((currentYear - i) + "-" + (currentYear - i + 1));
        	}
	    frm.set_df_property('year', 'options', yearList);
	   // frm.set_value('initiated_by', frappe.session.user);
	   frm.set_value('initiated_by', cur_frm.doc.owner);
	   frm.set_value('intiated_date', formattedDate);
	   
	   // role based access
	   frm.trigger('role_based_access');
        
        // role based access ends
        
        frappe.call({
            method: "frappe.client.get_list",
            args: {
                doctype: "New Branch Details",
                filters: {
                    year: frm.doc.year,
                    initiate: 1
                },
                fields: ["product_line","branch_category","zone","region","area","location_details"]
            },
            callback: function(r) {
                
                var product_line_options = r.message.map(function(d) { return d.product_line; });
                var branch_category_options = r.message.map(function(d) { return d.branch_category; });
                var zone_options = r.message.map(function(d) { return d.zone; });
                var region_options = r.message.map(function(d) { return d.region; });
                var area_options = r.message.map(function(d) { return d.area; });
                var location_details_options = r.message.map(function(d) { return d.location_details; });
                

                frm.set_df_property('product_line', 'options', product_line_options.join('\n'));
                frm.set_df_property('branch_category', 'options', branch_category_options.join('\n'));
                frm.set_df_property('zone', 'options', zone_options.join('\n'));                    
                frm.set_df_property('region', 'options', region_options.join('\n'));
                frm.set_df_property('area', 'options', area_options.join('\n'));
                frm.set_df_property('location_details', 'options', location_details_options.join('\n'));
            }
        });
    },
	// updating the regional list based on the zone selection
    year: function(frm) {
        var batch_size = 50;  // Number of records to fetch per batch
        var offset = 0;       // Starting offset    
        function fetchRecords() {
            frappe.call({
                method: "frappe.client.get_list",
                args: {
                    doctype: "New Branch Details",
                    filters: {
                        year: frm.doc.year,
                        initiate: 1
                    },
                    fields: ["product_line","branch_category","zone","region","area","location_details"],
                    limit_start: offset,
                    limit_page_length: batch_size
                },
                callback: function(r) {
                    
                    var product_line_options = r.message.map(function(d) { return d.product_line; });
                    var branch_category_options = r.message.map(function(d) { return d.branch_category; });
                    var zone_options = r.message.map(function(d) { return d.zone; });
                    var region_options = r.message.map(function(d) { return d.region; });
                    var area_options = r.message.map(function(d) { return d.area; });
                    var location_details_options = r.message.map(function(d) { return d.location_details; });
                    

                    frm.set_df_property('product_line', 'options', product_line_options.join('\n'));
                    frm.set_df_property('branch_category', 'options', branch_category_options.join('\n'));
                    frm.set_df_property('zone', 'options', zone_options.join('\n'));                    
                    frm.set_df_property('region', 'options', region_options.join('\n'));
                    frm.set_df_property('area', 'options', area_options.join('\n'));
                    frm.set_df_property('location_details', 'options', location_details_options.join('\n'));
    
                    // If there are more records, fetch the next batch
                    if (r.message && r.message.length === batch_size) {
                        offset += batch_size;
                        fetchRecords();
                    }
                }
            });
        }
            fetchRecords();  // Start fetching records
    },
    // map choose location
    map:function(frm){
        // console.log(JSON.parse(frm.doc.map));
        let mapdata = JSON.parse(cur_frm.doc.map).features[0];
        if(mapdata && mapdata.geometry.type =='Point'){
            let lat = mapdata.geometry.coordinates[1];
        	let lon = mapdata.geometry.coordinates[0];
        // 	console.log(lon,lat);
        	
        	frappe.call({
        		type: "GET",
        		url: `https://nominatim.openstreetmap.org/reverse?format=json&lat=${lat}&lon=${lon}`,
        		callback: function(r) {
        		  //  console.log(r.display_name);
        		    frm.set_value('geo_location', r.display_name);
        		}
        	});
        }
    },

    // role based access
    role_based_access: function(frm){
        let hasRole = frappe.user_roles.includes('Branch Initiator');
        if (hasRole) {
            frm.toggle_display('premise_information_section', false);
            frm.toggle_display('premise_related_information_section', false);
            frm.toggle_display('approvers_remark', false);
            frm.toggle_display('audit_trail_details_section', false);
            frm.toggle_display('premise_information_section', false);
            frm.toggle_display('premise_related_information_section', false);
            frm.toggle_display('commercial_details_section', false);
            frm.toggle_display('facilities_provided_section', false);
            frm.toggle_display('property_details_section', false);
            frm.toggle_display('owner_details_section', false);
            frm.toggle_display('owner_2_details_section', false);
            frm.toggle_display('deviation_and_other_details_section', false);
            frm.toggle_display('remark_and_actions_section', false);
            frm.toggle_display('audit_trail_details_section', false);
        } else {
            frm.toggle_display('premise_information_section', true);
            frm.toggle_display('premise_related_information_section', true);
            frm.toggle_display('approvers_remark', true);
            frm.toggle_display('audit_trail_details_section', true);
            frm.toggle_display('premise_information_section', true);
            frm.toggle_display('premise_related_information_section', true);
            frm.toggle_display('commercial_details_section', true);
            frm.toggle_display('facilities_provided_section', true);
            frm.toggle_display('property_details_section', true);
            frm.toggle_display('owner_details_section', true);
            frm.toggle_display('owner_2_details_section', true);
            frm.toggle_display('deviation_and_other_details_section', true);
            frm.toggle_display('remark_and_actions_section', true);
            frm.toggle_display('audit_trail_details_section', true);
            if (cur_frm.doc.responsible_person == frappe.session.user_email || frappe.user_roles.includes('Branch Responsible Person')) {
                frm.set_df_property('rent_per_sq_feet', 'reqd', 1);
                frm.set_df_property('monthly_rent', 'reqd', 1);
                frm.set_df_property('security_deposit', 'reqd', 1);
                frm.set_df_property('maintenance', 'reqd', 1);
                frm.set_df_property('lock_in_period', 'reqd', 1);
                frm.set_df_property('rent_free_period', 'reqd', 1);
                frm.set_df_property('stamp_duty_and_legal_expense_sharing_ratio_for_registration', 'reqd', 1);
                frm.set_df_property('rent_escalation', 'reqd', 1);
                frm.set_df_property('lease_period', 'reqd', 1);
                frm.set_df_property('lease_exit_notice_period_from_lessee', 'reqd', 1);
                frm.set_df_property('property_tax_liability', 'reqd', 1);
                frm.set_df_property('brokerage', 'reqd', 1);
                frm.set_df_property('reimbursement_by_landlord', 'reqd', 1);
                frm.set_df_property('furnished_or_unfurnished_office', 'reqd', 1);
                frm.set_df_property('signage_space_and_location_details', 'reqd', 1);
                frm.set_df_property('electricity_load_in_kva', 'reqd', 1);
                frm.set_df_property('wiring_to_be_provided_till_db_box_in_our_premises', 'reqd', 1);
                frm.set_df_property('water_line_specify_source', 'reqd', 1);
                frm.set_df_property('sewer_line_specify_source', 'reqd', 1);
                frm.set_df_property('parking_space_or_area', 'reqd', 1);
                frm.set_df_property('parking_number_of_two_wheeler', 'reqd', 1);
                frm.set_df_property('parking_number_of_four_wheeler', 'reqd', 1);
                frm.set_df_property('number_of_exclusive_toilets_available', 'reqd', 1);
                frm.set_df_property('flooring_available_vitrifies_tile_or_ceramic_tile_or_carpet', 'reqd', 1);
                frm.set_df_property('availability_of_fire_exit', 'reqd', 1);
                frm.set_df_property('lift_availability', 'reqd', 1);
                frm.set_df_property('rolling_shutter_in_the_front', 'reqd', 1);
                frm.set_df_property('space_for_generator_set', 'reqd', 1);
                frm.set_df_property('is_space_for_generator_rent_free', 'reqd', 1);
                frm.set_df_property('earth_points', 'reqd', 1);
                frm.set_df_property('specify_space_for_ac_outdoor_unit', 'reqd', 1);
                frm.set_df_property('availability_of_space_for_rf_pole', 'reqd', 1);
                frm.set_df_property('is_space_for_rf_pole_rent_free', 'reqd', 1);
                frm.set_df_property('availability_of_electrical_or_data_or_voice_cabling', 'reqd', 1);
                frm.set_df_property('windows_with_safety_grills', 'reqd', 1);
                frm.set_df_property('availability_of_pantry', 'reqd', 1);
                frm.set_df_property('total_no_of_floors_in_the_building', 'reqd', 1);
                frm.set_df_property('complete_address_of_the_property', 'reqd', 1);
                frm.set_df_property('proposed_floor_level', 'reqd', 1);
                frm.set_df_property('pin_code', 'reqd', 1);
                frm.set_df_property('geo_latitude', 'reqd', 1);
                frm.set_df_property('geo_longitude', 'reqd', 1);
                frm.set_df_property('basis_of_rent_calculation', 'reqd', 1);
                frm.set_df_property('bound_by_north', 'reqd', 1);
                frm.set_df_property('bound_by_east', 'reqd', 1);
                frm.set_df_property('bound_by_south', 'reqd', 1);
                frm.set_df_property('bound_by_west', 'reqd', 1);
                frm.set_df_property('built_up_area_sqft', 'reqd', 1);
                frm.set_df_property('carpet_area_sqft', 'reqd', 1);
                frm.set_df_property('ownerlandlord_name', 'reqd', 1);
                frm.set_df_property('owner_age', 'reqd', 1);
                frm.set_df_property('owners_father_or_spouse_name', 'reqd', 1);
                frm.set_df_property('complete_address_of_the_owner', 'reqd', 1);
                frm.set_df_property('phone_number', 'reqd', 1);
                frm.set_df_property('email_address', 'reqd', 1);
                frm.set_df_property('pan_number', 'reqd', 1);
                frm.set_df_property('gst_number', 'reqd', 1);
                frm.set_df_property('agreement_signed_by', 'reqd', 1);
                frm.set_df_property('poasauthorised_signatorys_name', 'reqd', 1);
                frm.set_df_property('poas_authorised_signatorys_age', 'reqd', 1);
                frm.set_df_property('poasauthorised_signatorys_fathers_or_spouse_name', 'reqd', 1);
                frm.set_df_property('poasauthorised_signatorys_complete_address', 'reqd', 1);
                frm.set_df_property('deviation_details_if_any', 'reqd', 1);
                frm.set_df_property('remark', 'reqd', 1);
            }
        }
    },
    
    // on submit form
    // 	on_submit(frm) {
    after_save(frm) {
	    // your code here
	
    if (cur_frm.doc.request_no == null || cur_frm.doc.request_no == "") {
	    frm.set_value('request_no', cur_frm.doc.name);
	}
	
	
    frappe.msgprint({
        title: "Submitted",
        message: "Data saved and sent to process,\n Request No: "+ cur_frm.doc.name,
        indicator: 'Green',
        primary_action: {
            action: function(){
                frappe.hide_msgprint();
            },
            label: 'OK'
        }
    });
    }
});
