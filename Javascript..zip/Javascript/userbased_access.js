frappe.ui.form.on('MyDocType', {
    onload: function(frm) {
        // Get the user's roles
        var roles = frappe.user_roles;

        // Define which roles should have access to specific tabs
        var allowedRoles = ['Role1', 'Role2'];  // Replace with your actual role names

        // Loop through each tab and hide/show based on roles
        frm.fields_dict['tabs'].sheets.forEach(function(sheet) {
            // Replace 'TabName' with your actual tab name
            if (sheet.label == 'TabName') {
                if (!allowedRoles.some(role => roles.includes(role))) {
                    // Hide the tab
                    frm.set_tab_visibility('TabName', false);
                }
            }
        });
    }
});


// ------------------------

frappe.ui.form.on('Purchase Order', {
    validate: (frm) => {
        
        // Doc Creation:
        if (!frm.doc.custom_created_by && frm.doc.workflow_state === 'Draft') {
            frm.doc.custom_created_by = frappe.session.user,
            frm.doc.custom_created_time = frappe.datetime.now_datetime();
        }

        // Doc Verification:
        else if ((frm.doc.custom_read_and_verified == 1) && (frm.doc.workflow_state === 'Verification Pending')){
            frm.doc.custom_verified_by = frappe.session.user,
            frm.doc.custom_verified_time = frappe.datetime.now_datetime();
        }
        else if ((frm.doc.custom_read_and_verified != 1) && (frm.doc.workflow_state === 'Verification Pending')){
            frm.doc.custom_verified_by = null,
            frm.doc.custom_verified_time = null
        }

        // Doc Approval:
        else if ((frm.doc.custom_read_and_approved == 1) && (frm.doc.workflow_state === 'Approval Pending by Manager')){
            frm.doc.custom_approved_by = frappe.session.user,
            frm.doc.custom_approved_time = frappe.datetime.now_datetime();
        }
        else if ((frm.doc.custom_read_and_approved != 1) && (frm.doc.workflow_state === 'Approval Pending by Manager')){
            frm.doc.custom_approved_by = null,
            frm.doc.custom_approved_time = null
        }
    }
});