frappe.ui.form.on('Proposed Branch Details', {
	refresh(frm) {
        let hasRole = frappe.user_roles.includes('Branch Initiator');
        // console.log(frappe.user_roles)
        // Hide the section if the user has the specified role
        if (hasRole) {
            frm.toggle_display('premise_information_section', false);
            frm.toggle_display('premise_related_information_section', false);
            frm.toggle_display('approvers_remark', false);
            frm.toggle_display('audit_trail_details_section', false);
            frm.toggle_display('premise_information_section', false);
            frm.toggle_display('premise_related_information_section', false);
            frm.toggle_display('commercial_details_section', false);
            frm.toggle_display('facilities_provided_section', false);
            frm.toggle_display('property_details_section', false);
            frm.toggle_display('owner_details_section', false);
            frm.toggle_display('owner_2_details_section', false);
            frm.toggle_display('deviation_and_other_details_section', false);
            frm.toggle_display('approvers_remark', false);
            frm.toggle_display('audit_trail_details_section', false);


        } else {
            frm.toggle_display('premise_information_section', true);
            frm.toggle_display('premise_related_information_section', true);
            frm.toggle_display('approvers_remark', true);
            frm.toggle_display('audit_trail_details_section', true);
            frm.toggle_display('premise_information_section', true);
            frm.toggle_display('premise_related_information_section', true);
            frm.toggle_display('commercial_details_section', true);
            frm.toggle_display('facilities_provided_section', true);
            frm.toggle_display('property_details_section', true);
            frm.toggle_display('owner_details_section', true);
            frm.toggle_display('owner_2_details_section', true);
            frm.toggle_display('deviation_and_other_details_section', true);
            frm.toggle_display('approvers_remark', true);
            frm.toggle_display('audit_trail_details_section', true);
            if (cur_frm.doc.responsible_person == frappe.session.user_email || frappe.user_roles.includes('Branch Responsible Person')) {
                frm.set_df_property('rent_per_sq_feet', 'reqd', 1);
                frm.set_df_property('monthly_rent', 'reqd', 1);
                frm.set_df_property('security_deposit', 'reqd', 1);
                frm.set_df_property('maintenance', 'reqd', 1);
                frm.set_df_property('lock_in_period', 'reqd', 1);
                frm.set_df_property('rent_free_period', 'reqd', 1);
                frm.set_df_property('stamp_duty_and_legal_expense_sharing_ratio_for_registration', 'reqd', 1);
                frm.set_df_property('rent_escalation', 'reqd', 1);
                frm.set_df_property('lease_period', 'reqd', 1);
                frm.set_df_property('lease_exit_notice_period_from_lessee', 'reqd', 1);
                frm.set_df_property('property_tax_liability', 'reqd', 1);
                frm.set_df_property('brokerage', 'reqd', 1);
                frm.set_df_property('reimbursement_by_landlord', 'reqd', 1);
                frm.set_df_property('furnished_or_unfurnished_office', 'reqd', 1);
                frm.set_df_property('signage_space_and_location_details', 'reqd', 1);
                frm.set_df_property('electricity_load_in_kva', 'reqd', 1);
                frm.set_df_property('wiring_to_be_provided_till_db_box_in_our_premises', 'reqd', 1);
                frm.set_df_property('water_line_specify_source', 'reqd', 1);
                frm.set_df_property('sewer_line_specify_source', 'reqd', 1);
                frm.set_df_property('parking_space_or_area', 'reqd', 1);
                frm.set_df_property('parking_number_of_two_wheeler', 'reqd', 1);
                frm.set_df_property('parking_number_of_four_wheeler', 'reqd', 1);
                frm.set_df_property('number_of_exclusive_toilets_available', 'reqd', 1);
                frm.set_df_property('flooring_available_vitrifies_tile_or_ceramic_tile_or_carpet', 'reqd', 1);
                frm.set_df_property('availability_of_fire_exit', 'reqd', 1);
                frm.set_df_property('lift_availability', 'reqd', 1);
                frm.set_df_property('rolling_shutter_in_the_front', 'reqd', 1);
                frm.set_df_property('space_for_generator_set', 'reqd', 1);
                frm.set_df_property('is_space_for_generator_rent_free', 'reqd', 1);
                frm.set_df_property('earth_points', 'reqd', 1);
                frm.set_df_property('specify_space_for_ac_outdoor_unit', 'reqd', 1);
                frm.set_df_property('availability_of_space_for_rf_pole', 'reqd', 1);
                frm.set_df_property('is_space_for_rf_pole_rent_free', 'reqd', 1);
                frm.set_df_property('availability_of_electrical_or_data_or_voice_cabling', 'reqd', 1);
                frm.set_df_property('windows_with_safety_grills', 'reqd', 1);
                frm.set_df_property('availability_of_pantry', 'reqd', 1);
                frm.set_df_property('total_no_of_floors_in_the_building', 'reqd', 1);
                frm.set_df_property('complete_address_of_the_property', 'reqd', 1);
                frm.set_df_property('proposed_floor_level', 'reqd', 1);
                frm.set_df_property('pin_code', 'reqd', 1);
                frm.set_df_property('geo_latitude', 'reqd', 1);
                frm.set_df_property('geo_longitude', 'reqd', 1);
                frm.set_df_property('basis_of_rent_calculation', 'reqd', 1);
                frm.set_df_property('bound_by_north', 'reqd', 1);
                frm.set_df_property('bound_by_east', 'reqd', 1);
                frm.set_df_property('bound_by_south', 'reqd', 1);
                frm.set_df_property('bound_by_west', 'reqd', 1);
                frm.set_df_property('built_up_area_sqft', 'reqd', 1);
                frm.set_df_property('carpet_area_sqft', 'reqd', 1);
                frm.set_df_property('ownerlandlord_name', 'reqd', 1);
                frm.set_df_property('owner_age', 'reqd', 1);
                frm.set_df_property('owners_father_or_spouse_name', 'reqd', 1);
                frm.set_df_property('complete_address_of_the_owner', 'reqd', 1);
                frm.set_df_property('phone_number', 'reqd', 1);
                frm.set_df_property('email_address', 'reqd', 1);
                frm.set_df_property('pan_number', 'reqd', 1);
                frm.set_df_property('gst_number', 'reqd', 1);
                frm.set_df_property('agreement_signed_by', 'reqd', 1);
                frm.set_df_property('poasauthorised_signatorys_name', 'reqd', 1);
                frm.set_df_property('poas_authorised_signatorys_age', 'reqd', 1);
                frm.set_df_property('poasauthorised_signatorys_fathers_or_spouse_name', 'reqd', 1);
                frm.set_df_property('poasauthorised_signatorys_complete_address', 'reqd', 1);
                frm.set_df_property('deviation_details_if_any', 'reqd', 1);
                frm.set_df_property('remark', 'reqd', 1);
            }
        }
	}
})

// cur_frm.doc.responsible_person == frappe.session.user_email