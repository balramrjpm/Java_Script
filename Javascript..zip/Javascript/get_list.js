frappe.ui.form.on('Proposed Branch Details', {
	refresh(frm) {
        // script for the producing the list of the past ten year
		let currentYear = new Date().getFullYear();
        let yearList = [];
        for(let i = 0; i < 10; i++) {
            yearList.push((currentYear - i) + "-" + (currentYear - i + 1));
	}
	    frm.set_df_property('year', 'options', yearList)
	},
	// updating the regional list based on the zone selection
    zone: function(frm) {
        var batch_size = 50;  // Number of records to fetch per batch
        var offset = 0;       // Starting offset
    
        function fetchRecords() {
            frappe.call({
                method: "frappe.client.get_list",
                args: {
                    doctype: "Regional Details",
                    filters: {
                        fk_zoneid: frm.doc.zone
                    },
                    fields: ["region"],
                    limit_start: offset,
                    limit_page_length: batch_size
                },
                callback: function(r) {
                    var region_options = r.message.map(function(d) { return d.region; });
                    console.log(region_options);
                    frm.set_df_property('region', 'options', region_options.join('\n'));
    
                    // If there are more records, fetch the next batch
                    if (r.message && r.message.length === batch_size) {
                        offset += batch_size;
                        fetchRecords();
                    }
                }
            });
        }
            fetchRecords();  // Start fetching records
    },
    // updating the area list based on the region selection
    region: function(frm) {
        var batch_size = 50;  // Number of records to fetch per batch
        var offset = 0;       // Starting offset
    
        function fetchRecords() {
            frappe.call({
                method: "frappe.client.get_list",
                args: {
                    doctype: "Area Details",
                    filters: {
                        fk_regionid: frm.doc.region
                    },
                    fields: ["area"],
                    limit_start: offset,
                    limit_page_length: batch_size
                },
                callback: function(r) {
                    var area_options = r.message.map(function(d) { return d.area; });
                    console.log(area_options);
                    frm.set_df_property('area', 'options', area_options.join('\n'));
    
                    // If there are more records, fetch the next batch
                    if (r.message && r.message.length === batch_size) {
                        offset += batch_size;
                        fetchRecords();
                    }
                }
            });
        }
        fetchRecords();  // Start fetching records
    },
    
    // field update based on the geo location script
    map:function(frm){
        // console.log(JSON.parse(frm.doc.map));
        let mapdata = JSON.parse(cur_frm.doc.map).features[0];
        if(mapdata && mapdata.geometry.type =='Point'){
            let lat = mapdata.geometry.coordinates[1];
        	let lon = mapdata.geometry.coordinates[0];
        // 	console.log(lon,lat);
        	
        	frappe.call({
        		type: "GET",
        		url: `https://nominatim.openstreetmap.org/reverse?format=json&lat=${lat}&lon=${lon}`,
        		callback: function(r) {
        		  //  console.log(r.display_name);
        		    frm.set_value('address', r.display_name);
        		}
        	})
        }
    }
})
