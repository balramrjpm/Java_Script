frappe.ui.form.on('Proposed Branch Details', {
	setup(frm) {
        // script for the producing the list of the past ten year
        let currentDate = new Date();
        // let formattedDate = frappe.datetime.str_to_user(currentDate, 'dd-mm-yyyy');
		let formattedDate = frappe.datetime.nowdate();
		let currentYear = new Date().getFullYear();
        let yearList = [];
        for(let i = 0; i < 10; i++) {
            yearList.push((currentYear - i) + "-" + (currentYear - i + 1));
        
	   }
	    frm.set_df_property('year', 'options', yearList);
	    frm.set_value('initiated_by', cur_frm.doc.owner);
	    frm.set_value('intiated_date', formattedDate);
	},
    refresh(frm) {

	   // frm.set_value('initiated_by', frappe.session.user);
	   
	   // role based access
	   let hasRole = frappe.user_roles.includes('Branch Initiator');
        // console.log(frappe.user_roles)
        // Hide the section if the user has the specified role
        if (hasRole && frappe.user.name !== "Administrator") {
            frm.toggle_display('premise_information_section', false);
            frm.toggle_display('premise_related_information_section', false);
            frm.toggle_display('approvers_remark', false);
            frm.toggle_display('audit_trail_details_section', false);

        } else {
            frm.toggle_display('premise_information_section', true);
            frm.toggle_display('premise_related_information_section', true);
            frm.toggle_display('approvers_remark', true);
            frm.toggle_display('audit_trail_details_section', true);
        }
        
        // role based access ends
        
        frappe.call({
            method: "frappe.client.get_list",
            args: {
                doctype: "New Branch Details",
                filters: {
                    'name': frm.doc.branch_initiation_id,
                    initiate: 1
                },
                fields: ["year","product_line","branch_category","zone","region","area","location_details"]
            },
            callback: function(r) {
                var year_options = r.message.map(function(d) { return d.year; });
                var product_line_options = r.message.map(function(d) { return d.product_line; });
                var branch_category_options = r.message.map(function(d) { return d.branch_category; });
                var zone_options = r.message.map(function(d) { return d.zone; });
                var region_options = r.message.map(function(d) { return d.region; });
                var area_options = r.message.map(function(d) { return d.area; });
                var location_details_options = r.message.map(function(d) { return d.location_details; });
                
                frm.set_df_property('year', 'options', year_options.join('\n'));
                frm.set_df_property('product_line', 'options', product_line_options.join('\n'));
                frm.set_df_property('branch_category', 'options', branch_category_options.join('\n'));
                frm.set_df_property('zone', 'options', zone_options.join('\n'));                    
                frm.set_df_property('region', 'options', region_options.join('\n'));
                frm.set_df_property('area', 'options', area_options.join('\n'));
                frm.set_df_property('location_details', 'options', location_details_options.join('\n'));
            }
        });
    },

	// updating the regional list based on the zone selection
    branch_initiation_id: function(frm) {
        var batch_size = 50;  // Number of records to fetch per batch
        var offset = 0;       // Starting offset    
        function fetchRecords() {
            frappe.call({
                method: "frappe.client.get_list",
                args: {
                    doctype: "New Branch Details",
                    filters: {
                        'name': frm.doc.branch_initiation_id,
                        initiate: 1
                    },
                    fields: ["year","product_line","branch_category","zone","region","area","location_details"],
                    limit_start: offset,
                    limit_page_length: batch_size
                },
                callback: function(r) {
                    var year_options = r.message.map(function(d) { return d.year; });
                    var product_line_options = r.message.map(function(d) { return d.product_line; });
                    var branch_category_options = r.message.map(function(d) { return d.branch_category; });
                    var zone_options = r.message.map(function(d) { return d.zone; });
                    var region_options = r.message.map(function(d) { return d.region; });
                    var area_options = r.message.map(function(d) { return d.area; });
                    var location_details_options = r.message.map(function(d) { return d.location_details; });
                    
                    frm.set_df_property('year', 'options', year_options.join('\n'));
                    frm.set_df_property('product_line', 'options', product_line_options.join('\n'));
                    frm.set_df_property('branch_category', 'options', branch_category_options.join('\n'));
                    frm.set_df_property('zone', 'options', zone_options.join('\n'));                    
                    frm.set_df_property('region', 'options', region_options.join('\n'));
                    frm.set_df_property('area', 'options', area_options.join('\n'));
                    frm.set_df_property('location_details', 'options', location_details_options.join('\n'));
    
                    // If there are more records, fetch the next batch
                    if (r.message && r.message.length === batch_size) {
                        offset += batch_size;
                        fetchRecords();
                    }
                }
            });
        }
            fetchRecords();  // Start fetching records
    },
    // map choose location
    map:function(frm){
        // console.log(JSON.parse(frm.doc.map));
        let mapdata = JSON.parse(cur_frm.doc.map).features[0];
        if(mapdata && mapdata.geometry.type =='Point'){
            let lat = mapdata.geometry.coordinates[1];
        	let lon = mapdata.geometry.coordinates[0];
        // 	console.log(lon,lat);
        	
        	frappe.call({
        		type: "GET",
        		url: `https://nominatim.openstreetmap.org/reverse?format=json&lat=${lat}&lon=${lon}`,
        		callback: function(r) {
        		  //  console.log(r.display_name);
        		    frm.set_value('geo_location', r.display_name);
        		}
        	});
        }
    },
    
    // on submit form
// 	on_submit(frm) {
    after_save(frm) {
	// your code here
	frm.set_value('request_no', cur_frm.doc.name);
	
    frappe.msgprint({
        title: "Submitted",
        message: "Data saved and sent to process,\n Request No: "+ cur_frm.doc.name,
        indicator: 'Green',
        primary_action: {
            action: function(){
                frappe.hide_msgprint();
            },
            label: 'OK'
        }
    });
}
});