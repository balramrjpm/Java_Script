frappe.ui.form.on('Proposed Branch Details', {
    onload: function(frm) {
        // Replace 'link_fieldname' with the actual name of your link field
        frm.fields_dict['branch_initiation_id'].get_query = function(doc, cdt, cdn) {
            return {
                query: "frappe.controllers.queries.doctype_query",
                filters: {
                    ignore_link_field: true
                }
            };
        };
    }
});