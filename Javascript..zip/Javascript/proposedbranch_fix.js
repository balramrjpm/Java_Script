frappe.ui.form.on('Proposed Branch Details', {
	setup(frm) {
        // script for the producing the list of the past ten year
        let currentDate = new Date();
        // let formattedDate = frappe.datetime.str_to_user(currentDate, 'dd-mm-yyyy');
		let formattedDate = frappe.datetime.nowdate();
		let currentYear = new Date().getFullYear();
        let yearList = [];
        for(let i = 0; i < 10; i++) {
            yearList.push((currentYear - i) + "-" + (currentYear - i + 1));
	}
	    frm.set_df_property('year', 'options', yearList)
	    frm.set_value('initiated_by', frappe.session.user)
	    frm.set_value('intiated_date', formattedDate)
	},
    refresh(frm) {
        let currentDate = new Date();
        // let formattedDate = frappe.datetime.str_to_user(currentDate, 'dd-mm-yyyy');
		let formattedDate = frappe.datetime.nowdate();
		let currentYear = new Date().getFullYear();
        let yearList = [];
        for(let i = 0; i < 10; i++) {
            yearList.push((currentYear - i) + "-" + (currentYear - i + 1));
        	}
	    frm.set_df_property('year', 'options', yearList)
	    frm.set_value('initiated_by', frappe.session.user)
	    frm.set_value('intiated_date', formattedDate)
        
        frappe.call({
            method: "frappe.client.get_list",
            args: {
                doctype: "New Branch Details",
                filters: {
                    year: frm.doc.year,
                    initiate: 1
                },
                fields: ["product_line","branch_category","zone","region","area","location_details"]
            },
            callback: function(r) {
                
                var product_line_options = r.message.map(function(d) { return d.product_line; });
                var branch_category_options = r.message.map(function(d) { return d.branch_category; });
                var zone_options = r.message.map(function(d) { return d.zone; });
                var region_options = r.message.map(function(d) { return d.region; });
                var area_options = r.message.map(function(d) { return d.area; });
                var location_details_options = r.message.map(function(d) { return d.location_details; });
                

                frm.set_df_property('product_line', 'options', product_line_options.join('\n'));
                frm.set_df_property('branch_category', 'options', branch_category_options.join('\n'));
                frm.set_df_property('zone', 'options', zone_options.join('\n'));                    
                frm.set_df_property('region', 'options', region_options.join('\n'));
                frm.set_df_property('area', 'options', area_options.join('\n'));
                frm.set_df_property('location_details', 'options', location_details_options.join('\n'));
            }
        });
    },
	// updating the regional list based on the zone selection
    year: function(frm) {
        var batch_size = 50;  // Number of records to fetch per batch
        var offset = 0;       // Starting offset    
        function fetchRecords() {
            frappe.call({
                method: "frappe.client.get_list",
                args: {
                    doctype: "New Branch Details",
                    filters: {
                        year: frm.doc.year,
                        initiate: 1
                    },
                    fields: ["product_line","branch_category","zone","region","area","location_details"],
                    limit_start: offset,
                    limit_page_length: batch_size
                },
                callback: function(r) {
                    
                    var product_line_options = r.message.map(function(d) { return d.product_line; });
                    var branch_category_options = r.message.map(function(d) { return d.branch_category; });
                    var zone_options = r.message.map(function(d) { return d.zone; });
                    var region_options = r.message.map(function(d) { return d.region; });
                    var area_options = r.message.map(function(d) { return d.area; });
                    var location_details_options = r.message.map(function(d) { return d.location_details; });
                    

                    frm.set_df_property('product_line', 'options', product_line_options.join('\n'));
                    frm.set_df_property('branch_category', 'options', branch_category_options.join('\n'));
                    frm.set_df_property('zone', 'options', zone_options.join('\n'));                    
                    frm.set_df_property('region', 'options', region_options.join('\n'));
                    frm.set_df_property('area', 'options', area_options.join('\n'));
                    frm.set_df_property('location_details', 'options', location_details_options.join('\n'));
    
                    // If there are more records, fetch the next batch
                    if (r.message && r.message.length === batch_size) {
                        offset += batch_size;
                        fetchRecords();
                    }
                }
            });
        }
            fetchRecords();  // Start fetching records
    }
})